-- Count the number of apps per content rating (e.g., Everyone, Teen)

select contentRating,count(app_id) as number_of_apps
	from apps
    group by contentRating;
    