-- Get the most common Android version requirement

select androidVersion,count(*) as commonly_used
	from apps_details
    group by androidVersion
    order by commonly_used desc
    limit 1;
