-- Find all apps that contain ads

select title
	from apps
    where containsAds = 'TRUE';