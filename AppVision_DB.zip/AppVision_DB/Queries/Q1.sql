-- List all apps with more than 10 million installs

select title,installs
	from apps
    where installs >= 10000000;