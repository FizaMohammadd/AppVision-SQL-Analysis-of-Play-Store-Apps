-- Get top 5 highest-rated apps (score)

select title,score
	from apps
    order by score desc
    limit 5;