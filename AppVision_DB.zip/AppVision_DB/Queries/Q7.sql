--  Which developer has the most apps on the store?

with dev_cnt as (
select developer,count(*) as app_cnt
	from apps
    group by developer),
max_cnt as (
select max(app_cnt) as max_app_cnt
	from dev_cnt
)
select dc.developer,dc.app_cnt
	from dev_cnt as dc
    join max_cnt as mc
    on dc.app_cnt = mc.max_app_cnt;