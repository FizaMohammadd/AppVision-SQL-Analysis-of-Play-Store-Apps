-- . Find average rating of apps with and without ads

select containsAds, round(avg(score),2) as avg_rating
	from apps
    group by containsAds;