-- Find the Top-Rated App Per Category of Install Count

with install_buckets as (
  select
    a.title,
    a.developer,
    a.score,
    a.installs,
    case
      when installs < 10000 then '0–10K'
      when installs < 100000 then '10K–100K'
      when installs < 1000000 then '100K–1M'
      when installs < 10000000 then '1M–10M'
      else '10M+'
    end as install_range
  from apps a
),
ranked_apps as (
  select *,
         rank() over (partition by install_range order by score desc) as score_rank
  from install_buckets
)
select title, developer, install_range, score
	from ranked_apps
	where score_rank = 1
	order by install_range;
