--  Find all apps developed by 'BYJU'S'

select title,developer
	from apps
    where developer like '%BYJU%';