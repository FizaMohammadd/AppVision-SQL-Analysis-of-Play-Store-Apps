--  Rank all apps by score within each developer using a window function

select title,developer,score,
	rank()over(partition by developer order by score desc) as score_rank
	from apps;