-- Find developers with more than 3 apps whose average score is below 3.5

select developer,count(*) as no_of_apps, round(avg(score),2) as Avg_score
	from apps
    group by developer
    having count(*) > 3 and Avg_score < 3.5;
    