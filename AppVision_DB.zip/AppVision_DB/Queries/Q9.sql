--  Label apps as 'Hit', 'Average', 'Low' based on score

select title,score,
	case
		when score >= 4.5 then 'Hit'
        when score >= 3.5 then 'Average'
        else 'Low'
	end as rating_label
	from apps;